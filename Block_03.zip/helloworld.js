const requestListener = function (req, res) {
    switch (req.method) {
        case 'GET':
            res.writeHead(200);
            res.end(JSON.stringify({ msg: "HELLO WORLD!" }))
            break;
        default:
            res.writeHead(404);
            res.end(JSON.stringify({ errMsg: "Ресурса не существует" }))
            return;
    }
}

module.exports = requestListener